#!/usr/bin/env python3
# ===================================================================
# 🔥 ARIYAN BOT - MULTI-SERVER KEEP ALIVE & CONCURRENT SPAM SYSTEM 🔥
# ===================================================================

import subprocess, sys, importlib, os, json, time, ssl, random, asyncio, threading
from datetime import datetime

# ---------- AUTO INSTALL ----------
required_modules = [
    "aiohttp", "pycryptodome", "python-telegram-bot", "protobuf-decoder"
]
def install_missing_modules():
    for m in required_modules:
        try:
            importlib.import_module(m.replace("-","_"))
        except ImportError:
            subprocess.check_call([sys.executable,"-m","pip","install",m])
install_missing_modules()

import aiohttp
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from protobuf_decoder.protobuf_decoder import Parser

# Protobuf files (আপনার লোকাল ফাইলসমূহ)
from xPARA import *
from xHeaders import *
from Pb2 import MajoRLoGinrEs_pb2, PorTs_pb2, MajoRLoGinrEq_pb2

# ========== CONFIG ==========
TELEGRAM_TOKEN = "8328984703:AAHmV_u1y6TlF86CpR-3JVsepg9T1WQFa60"
login_url, ob, version = "https://loginbp.ggpolarbear.com/", "OB54", "1.126.7"
TIMEOUT = aiohttp.ClientTimeout(total=15)

# গ্লোবাল ডিকশনারি ও ডাটাবেজ
connected_clients_bd = {}
connected_clients_ind = {}
active_spam_tasks = {} # target_uid -> asyncio.Task

# ---------- BOXED TEXT ----------
def boxed(text, title="ARIYAN BOT"):
    lines = text.split('\n')
    max_len = max(len(line) for line in lines) + 4
    border = "╔"+"═"*(max_len-2)+"╗"
    mid = f"║ {title.center(max_len-4)} ║"
    sep = "╠"+"═"*(max_len-2)+"╣"
    footer = "╚"+"═"*(max_len-2)+"╝"
    content = "\n".join(f"║ {line.ljust(max_len-4)} ║" for line in lines)
    return f"```\n{border}\n{mid}\n{sep}\n{content}\n{footer}\n```"

# ---------- HELPERS ----------
def Uaa():
    versions = ['5.0.1B2','5.1.0P1','5.2.0B1']
    models = ['SM-A125F','Redmi 9A','POCO M3']
    android = random.choice(['11','12','13'])
    return f"GarenaMSDK/{random.choice(versions)}({random.choice(models)};Android {android};en-US;USA;)"

Hr = {
    'User-Agent': Uaa(),
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/x-www-form-urlencoded",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
    'ReleaseVersion': ob
}

def get_random_color():
    colors = ["[FF0000]", "[00FF00]", "[0000FF]", "[FFFF00]", "[FF00FF]", "[00FFFF]", "[FFFFFF]", "[FFA500]", "[FFC0CB]", "[FFD700]"]
    return random.choice(colors)

async def EnC_Vr(N):
    if N<0: return b''
    H = []
    while True:
        RedZed = N & 0x7F
        N >>= 7
        if N: RedZed |= 0x80
        H.append(RedZed)
        if not N: break
    return bytes(H)

async def CrEaTe_VarianT(fn, val):
    return await EnC_Vr((fn<<3)|0) + await EnC_Vr(val)

async def CrEaTe_LenGTh(fn, val):
    ev = val.encode() if isinstance(val,str) else val
    return await EnC_Vr((fn<<3)|2) + await EnC_Vr(len(ev)) + ev

async def CrEaTe_ProTo(fields):
    packet = bytearray()
    for f,v in fields.items():
        if isinstance(v,dict):
            nested = await CrEaTe_ProTo(v)
            packet.extend(await CrEaTe_LenGTh(f, nested))
        elif isinstance(v,int):
            packet.extend(await CrEaTe_VarianT(f,v))
        elif isinstance(v,(str,bytes)):
            packet.extend(await CrEaTe_LenGTh(f,v))
    return bytes(packet)

async def DecodE_HeX(H):
    F = str(hex(H))[2:]
    return "0"+F if len(F)==1 else F

async def EnC_PacKeT(HeX, K, V):
    cipher = AES.new(K, AES.MODE_CBC, V)
    return cipher.encrypt(pad(bytes.fromhex(HeX),16)).hex()

async def GeneRaTePk(Pk, N, K, V):
    PkEnc = await EnC_PacKeT(Pk, K, V)
    _ = await DecodE_HeX(len(PkEnc)//2)
    HeadEr = N+"000000" if len(_)==2 else N+"00000" if len(_)==3 else N+"0000" if len(_)==4 else N+"000"
    return bytes.fromhex(HeadEr+_+PkEnc)


# ==================== STATUS DECODER HELPERS (PURE PYTHON) ====================
def _rdVr(data, pos):
    n = 0; sh = 0
    while True:
        b = data[pos]; pos += 1
        n |= (b & 0x7F) << sh; sh += 7
        if not b & 0x80: break
    return n, pos

def _pbF(data):
    out = {}; pos = 0
    while pos < len(data):
        try:
            tag, pos = _rdVr(data, pos)
            fn = tag >> 3; wt = tag & 0x7
            if wt == 0:
                v, pos = _rdVr(data, pos); out[fn] = v
            elif wt == 2:
                ln, pos = _rdVr(data, pos); out[fn] = data[pos:pos+ln]; pos += ln
            elif wt == 1:
                out[fn] = data[pos:pos+8]; pos += 8
            elif wt == 5:
                out[fn] = data[pos:pos+4]; pos += 4
            else: break
        except: break
    return out

async def _vr(n):
    h = []
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        h.append(b)
        if not n: break
    return bytes(h)

async def _enc(hx, k, v):
    return AES.new(k, AES.MODE_CBC, v).encrypt(pad(bytes.fromhex(hx), 16)).hex()

async def _hx(n):
    f = hex(n)[2:]
    return ('0' + f) if len(f) == 1 else f

async def _var(fn, val):
    return await _vr((fn << 3) | 0) + await _vr(val)

async def _len(fn, val):
    e = val.encode() if isinstance(val, str) else val
    return await _vr((fn << 3) | 2) + await _vr(len(e)) + e

async def _pb(flds):
    p = bytearray()
    for f, v in flds.items():
        if isinstance(v, dict): p.extend(await _len(f, await _pb(v)))
        elif isinstance(v, int): p.extend(await _var(f, v))
        elif isinstance(v, (str, bytes)): p.extend(await _len(f, v))
    return p

async def _pk(px, n, k, v):
    e = await _enc(px, k, v)
    _ = await _hx(len(e) // 2)
    m = {2:'000000', 3:'00000', 4:'000', 5:'00'}
    length_prefix = m.get(len(_), '0000')
    return bytes.fromhex(n + length_prefix + _ + e)

async def _fix(rs):
    d = {}
    for r in rs:
        fd = {'wire_type': r.wire_type}
        if r.wire_type in ('varint', 'string', 'bytes'): fd['data'] = r.data
        elif r.wire_type == 'length_delimited': fd['data'] = await _fix(r.data.results)
        d[r.field] = fd
    return d

async def _parse(hx):
    try: return json.dumps(await _fix(Parser().parse(hx)))
    except: return None

async def _uidEnc(uid):
    return (await _pb({1: int(uid)})).hex()[2:]

async def _stPkt(uid, k, v):
    ue = await _uidEnc(int(uid))
    return await _pk(f"080112090A05{ue}1005", '0F15', k, v)

async def _rmPkt(ruid, k, v):
    return await _pk((await _pb({1: 1, 2: {1: ruid, 3: {}, 4: 1, 6: 'en'}})).hex(), '0E15', k, v)

def _pStatus(pkt):
    try:
        data = json.loads(pkt)
        if '5' not in data or 'data' not in data['5']: 
            return {'status': 'OFFLINE', 'status_emoji': '💤', 'description': 'প্লেয়ার অফলাইনে আছেন (Offline)', 'styled_summary': '💤 Player is currently OFFLINE (অফলাইন)'}
        jd = data['5']['data']
        if '1' not in jd or 'data' not in jd['1']: 
            return {'status': 'OFFLINE', 'status_emoji': '💤', 'description': 'প্লেয়ার অফলাইনে আছেন (Offline)', 'styled_summary': '💤 Player is currently OFFLINE (অফলাইন)'}
        d = jd['1']['data']
        if '3' not in d or 'data' not in d['3']: 
            return {'status': 'OFFLINE', 'status_emoji': '💤', 'description': 'প্লেয়ার অফলাইনে আছেন (Offline)', 'styled_summary': '💤 Player is currently OFFLINE (অফলাইন)'}
        
        st = d['3']['data']
        base = {
            1: 'SOLO', 2: 'INSQUAD', 3: 'INGAME', 4: 'IN_ROOM', 5: 'INGAME', 6: 'SOCIAL_ISLAND', 7: 'MATCHMAKING'
        }.get(st, 'OFFLINE')
        
        emoji = {
            'SOLO': '👤', 'INSQUAD': '👥', 'INGAME': '🎮', 'IN_ROOM': '🏠', 'SOCIAL_ISLAND': '🏝️', 'MATCHMAKING': '⏳', 'OFFLINE': '💤'
        }.get(base, '💤')
        
        desc = {
            'SOLO': 'লবিতে একা দাঁড়িয়ে আছেন (Solo in Lobby)',
            'INSQUAD': 'গ্রুপে বা স্কোয়াডে আছেন (In Group/Squad)',
            'INGAME': 'ম্যাচের ভেতরে খেলছেন (In Game/Playing)',
            'IN_ROOM': 'কাস্টম রুমে আছেন (In Custom Room)',
            'SOCIAL_ISLAND': 'সোশ্যাল আইল্যান্ডে আছেন (In Social Island)',
            'MATCHMAKING': 'ম্যাচ স্টার্ট হওয়ার জন্য অপেক্ষা করছেন (Matchmaking)',
            'OFFLINE': 'প্লেয়ার অফলাইনে আছেন (Offline)'
        }.get(base, 'প্লেয়ার অফলাইনে আছেন (Offline)')
        
        mode = None
        f14 = d.get('14', {}).get('data') if '14' in d else None
        if f14 == 1: mode = 'TRAINING'
        elif f14 == 2: mode = 'SOCIAL_ISLAND'
            
        m5 = d.get('5', {}).get('data') if '5' in d else None
        m6 = d.get('6', {}).get('data') if '6' in d else None
        mm = {
            (2, 1): 'BR_RANK (র‍্যাঙ্ক ম্যাচ)',
            (5, 23): 'TRAINING (ট্রেনিং গ্রাউন্ড)',
            (6, 15): 'CS_RANK (ক্ল্যাশ স্কোয়াড র‍্যাঙ্ক)',
            (1, 43): 'LONE_WOLF (লোন উলফ)',
            (1, 1): 'BERMUDA (বারমুডা ক্লাসিক)',
            (1, 15): 'CLASH_SQUAD (ক্ল্যাশ স্কোয়াড ক্লাসিক)',
            (1, 29): 'CONVOY_CRUNCH',
            (1, 61): 'FREE_FOR_ALL'
        }
        if (m5, m6) in mm: mode = mm[(m5, m6)]
        
        time_playing = None
        tg = d.get('4', {}).get('data', 0) if '4' in d else 0
        if tg:
            try:
                d_diff = int((datetime.now() - datetime.fromtimestamp(tg)).total_seconds())
                mn = (abs(d_diff) % 3600) // 60
                sc = abs(d_diff) % 60
                time_playing = f"{mn:02}m {sc:02}s"
            except: pass
        
        summary = f"{emoji} Player is currently {base} ({desc})"
        if base == 'INGAME':
            summary = f"🎮 Player is currently IN-GAME (ম্যাচ খেলছেন) | Mode: {mode if mode else 'Unknown'} | Play Time: {time_playing if time_playing else 'N/A'}"
        elif base == 'SOLO':
            summary = "👤 Player is currently SOLO in Lobby (লবিতে একা দাঁড়িয়ে আছেন)"
        elif base == 'MATCHMAKING':
            summary = "⏳ Player is currently MATCHMAKING (ম্যাচ মেকিং করছেন)"
        elif base == 'SOCIAL_ISLAND':
            summary = "🏝️ Player is currently in SOCIAL ISLAND (সোশ্যাল আইল্যান্ডে আছেন)"
        
        res = {
            'status': base, 'status_emoji': emoji, 'description': desc, 'styled_summary': summary,
            'details': {'mode': mode, 'time_playing': time_playing}
        }
        
        if base == 'INSQUAD':
            squad_owner = d.get('8', {}).get('data') if '8' in d else None
            team_code = d.get('11', {}).get('data') if '11' in d else None
            gc = d.get('9', {}).get('data', 0) if '9' in d else 0
            cm = d.get('10', {}).get('data', 0) + 1 if '10' in d else 0
            squad_size = f"{gc}/{cm}" if gc else None
            
            res['details'].update({
                'team_code': str(team_code) if team_code else None,
                'squad_leader_id': squad_owner,
                'squad_size': squad_size
            })
            res['styled_summary'] = f"👥 Player is currently in a SQUAD (গ্রুপে আছেন) | Size: {squad_size} | Team Code: {team_code if team_code else 'N/A'} | Leader: {squad_owner if squad_owner else 'N/A'}"
            
        elif base == 'IN_ROOM':
            room_id = d.get('15', {}).get('data') if '15' in d else None
            room_owner = d.get('1', {}).get('data') if '1' in d else None
            players_count = f"{d.get('17',{}).get('data',0)}/{d.get('18',{}).get('data',0)}"
            
            res['details'].update({
                'room_id': room_id, 'room_owner_id': room_owner, 'room_players': players_count
            })
            res['styled_summary'] = f"🏠 Player is currently inside a CUSTOM ROOM (কাস্টম রুমে আছেন) | ID: {room_id} | Players: {players_count} | Owner: {room_owner}"
            
        return res
    except Exception as e:
        print("Error parsing status:", e)
        return {
            'status': 'PARSE_ERROR', 'status_emoji': '❌',
            'description': 'স্ট্যাটাস পার্স করতে ত্রুটি হয়েছে (Parse Error)',
            'styled_summary': '❌ Error parsing player status.'
        }

def _pRoom(pkt):
    try:
        data = json.loads(pkt)
        if '5' not in data or 'data' not in data['5']: return None
        jd = data['5']['data']
        if '1' not in jd or 'data' not in jd['1']: return None
        rd = jd['1']['data']
        
        mm = {
            1: 'BERMUDA (বারমুডা ক্লাসিক)', 201: 'BATTLE_CAGE (ব্যাটল কেজ)',
            15: 'CLASH_SQUAD (ক্ল্যাশ স্কোয়াড)', 43: 'LONE_WOLF (লোন উলফ)',
            3: 'RUSH_HOUR', 27: 'BOMB_SQUAD_5V5', 24: 'DEATH_MATCH'
        }
        
        return {
            'room_id': int(rd['1']['data']) if '1' in rd else None,
            'room_name': rd['2']['data'] if '2' in rd else 'UNKNOWN',
            'owner_uid': int(rd['37']['data']['1']['data']) if '37' in rd and 'data' in rd['37'] else None,
            'mode': mm.get(rd.get('4', {}).get('data'), 'UNKNOWN'),
            'players': f"{rd.get('6',{}).get('data',0)}/{rd.get('7',{}).get('data',0)}",
            'spectators': rd.get('9', {}).get('data', 0),
            'emulator_block': bool(rd.get('17', {}).get('data', 1)),
        }
    except Exception as e:
        print("Error parsing room info:", e)
        return None

def generate_styled_box(uid, data):
    status = data.get('status', 'OFFLINE')
    emoji = data.get('status_emoji', '💤')
    desc = data.get('description', 'প্লেয়ার অফলাইনে আছেন (Offline)')
    details = data.get('details', {})
    
    box =  "╔═══════════════════════════════════════════════════════════════════════╗\n"
    box += "║                      🌟 WINTER ARIYAN PLAYER STATUS 🌟               ║\n"
    box += "╠═══════════════════════════════════════════════════════════════════════╣\n"
    box += f"  👤 Target UID      :: {uid}\n"
    box += f"  📊 Garena State    :: {emoji} {status}\n"
    box += f"  📝 Description     :: {desc}\n"
    
    if status == 'INGAME':
        box += f"  🎮 Active Mode     :: {details.get('mode', 'N/A')}\n"
        box += f"  ⏱️ Time Playing    :: {details.get('time_playing', 'N/A')}\n"
    elif status == 'INSQUAD':
        box += f"  👥 Team Code       :: {details.get('team_code', 'N/A')}\n"
        box += f"  👑 Squad Leader    :: {details.get('squad_leader_id', 'N/A')}\n"
        box += f"  📊 Squad Size      :: {details.get('squad_size', 'N/A')}\n"
    elif status == 'IN_ROOM':
        box += f"  🏠 Custom Room ID  :: {details.get('room_id', 'N/A')}\n"
        box += f"  👥 Room Players    :: {details.get('room_players', 'N/A')}\n"
        box += f"  👑 Room Owner UID  :: {details.get('room_owner_id', 'N/A')}\n"
        
        room_info = data.get('room_info')
        if room_info:
            box += f"  🏷️ Room Name       :: {room_info.get('room_name', 'N/A')}\n"
            box += f"  🎮 Room Mode       :: {room_info.get('mode', 'N/A')}\n"
            box += f"  👁️ Spectators      :: {room_info.get('spectators', 0)}\n"
            box += f"  🚫 Emulator Block  :: {'YES' if room_info.get('emulator_block') else 'NO'}\n"
            
    box += "╠═══════════════════════════════════════════════════════════════════════╣\n"
    box += "║                         👑 POWERED BY WINTER ARIYAN 👑                ║\n"
    box += "╚═══════════════════════════════════════════════════════════════════════╝"
    return box

async def _rAll(reader, timeout=0.5):
    buf = b''
    while True:
        try: 
            chunk = await asyncio.wait_for(reader.read(65536), timeout=timeout)
        except asyncio.TimeoutError: 
            break
        if not chunk: 
            break
        buf += chunk
    return buf

async def _scan(buf, k, v):
    h = buf.hex()
    for mk, pt in [('0f00','0f'),('0e00','0e')]:
        i = h.find(mk)
        if i != -1 and i % 2 == 0: return pt, h[i + 10:]
    if len(buf) > 5:
        pl = buf[5:]; pl = pl[:len(pl) - (len(pl) % 16)]
        if len(pl) >= 16:
            try:
                dc = unpad(AES.new(k, AES.MODE_CBC, v).decrypt(pl), 16).hex()
                for mk, pt in [('0f00','0f'),('0e00','0e')]:
                    i = dc.find(mk)
                    if i != -1 and i % 2 == 0: return pt, dc[i + 10:]
            except: pass
    return None, None

# ==================== ACTIVE BOT SESSION ON-DEMAND QUERY ====================
async def _query(uid, bot):
    """অনলাইন বটের সচল TCP কানেকশন ব্যবহার করে কোনো নতুন সকেট খোলা ছাড়াই সরাসরি কুয়েরি"""
    if not bot.is_online or not bot.online_writer:
        return {
            'status': 'NO_RESPONSE', 'status_emoji': '❌',
            'description': 'বটটি অফলাইন রয়েছে (Bot is Offline)',
            'styled_summary': '❌ Selected bot is currently offline.'
        }
        
    async with bot.query_lock:
        bot.query_future = asyncio.get_event_loop().create_future()
        try:
            pkt = await _stPkt(uid, bot.key, bot.iv)
            bot.online_writer.write(pkt)
            await bot.online_writer.drain()
            
            buf = await asyncio.wait_for(bot.query_future, timeout=2.0)
        except asyncio.TimeoutError:
            return {
                'status': 'NO_RESPONSE', 'status_emoji': '❌',
                'description': 'সার্ভার থেকে কোনো রেসপন্স পাওয়া যায়নি (No Response)',
                'styled_summary': '❌ Garena Server did not respond.'
            }
        except Exception as e:
            return {
                'status': 'PARSE_ERROR', 'status_emoji': '❌',
                'description': f'কানেকশন ত্রুটি: {e}',
                'styled_summary': f'❌ Connection Error: {e}'
            }
        finally:
            bot.query_future = None
            
        pt, pl = await _scan(buf, bot.key, bot.iv)
        if pt == '0f':
            raw = await _parse(pl)
            if not raw:
                return {
                    'status': 'PARSE_ERROR', 'status_emoji': '❌',
                    'description': 'স্ট্যাটাস পার্স করতে ত্রুটি হয়েছে (Parse Error)',
                    'styled_summary': '❌ Garena response parse error.'
                }
            
            info = _pStatus(raw)
            
            if info.get('status') == 'IN_ROOM' and info.get('details', {}).get('room_id'):
                room_id = info['details']['room_id']
                bot.query_future = asyncio.get_event_loop().create_future()
                try:
                    bot.online_writer.write(await _rmPkt(int(room_id), bot.key, bot.iv))
                    await bot.online_writer.drain()
                    
                    rb = await asyncio.wait_for(bot.query_future, timeout=2.0)
                    rt, rp = await _scan(rb, bot.key, bot.iv)
                    if rt == '0e':
                        rr = await _parse(rp)
                        if rr:
                            room_details = _pRoom(rr)
                            info['room_info'] = room_details
                            if room_details:
                                info['styled_summary'] = f"🏠 Player is currently inside CUSTOM ROOM: '{room_details['room_name']}' (ID: {room_details['room_id']}) | Mode: {room_details['mode']} | Players: {room_details['players']} | Spectators: {room_details['spectators']} | Emulator Blocked: {room_details['emulator_block']}"
                except Exception:
                    pass
                finally:
                    bot.query_future = None
                    
            return info
            
        elif pt == '0e':
            raw = await _parse(pl)
            if raw:
                room_details = _pRoom(raw)
                return {
                    'status': 'IN_ROOM', 'status_emoji': '🏠',
                    'description': 'কাস্টম রুমে আছেন (In Custom Room)',
                    'styled_summary': f"🏠 Player is currently inside CUSTOM ROOM: '{room_details['room_name']}' (ID: {room_details['room_id']}) | Mode: {room_details['mode']} | Players: {room_details['players']}",
                    'room_info': room_details
                }
            return {'status': 'PARSE_ERROR'}
            
        return {
            'status': 'UNKNOWN', 'status_emoji': '❓',
            'description': 'অজানা স্ট্যাটাস বা সেশন এরর (Unknown)',
            'styled_summary': '❓ Garena session handshake error.'
        }


# ========== LOGIN & AUTH (KEEP ALIVE) - COMPLETELY FIXED ==========
async def GeNeRaTeAccAccess(uid, password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    headers = {"Host":"100067.connect.garena.com","User-Agent":Uaa(),"Content-Type":"application/x-www-form-urlencoded","Connection":"close"}
    data = {"uid":uid,"password":password,"response_type":"token","client_type":"2","client_secret":"2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3","client_id":"100067"}
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
            async with session.post(url, headers=headers, data=data) as resp:
                if resp.status != 200: return None, None
                data = await resp.json()
                return data.get("open_id"), data.get("access_token")
    except Exception as e:
        print(f"⚠️ Garena OAuth error: {e}")
        return None, None

async def EncRypTMajoRLoGin(open_id, access_token):
    major_login = MajoRLoGinrEq_pb2.MajorLogin()
    major_login.event_time = str(datetime.now())[:-7]
    major_login.game_name = "free fire"
    major_login.platform_id = 2
    major_login.client_version = "1.126.7"
    major_login.client_version_code = "2024010012"
    major_login.system_software = "Android OS 11 / API-30 (RQ3A.210805.001)"
    major_login.system_hardware = "Handheld"    
    major_login.device_type = "Handheld"
    major_login.telecom_operator = "Verizon"
    major_login.network_type = "WIFI"
    major_login.screen_width = 1080
    major_login.screen_height = 2400
    major_login.screen_dpi = "440"
    major_login.processor_details = "ARMv8"
    major_login.memory = 6144
    major_login.gpu_renderer = "Adreno (TM) 650"
    major_login.gpu_version = "OpenGL ES 3.2 V@1.50"
    major_login.graphics_api = "OpenGLES3"
    major_login.supported_astc_bitset = 16383
    major_login.unique_device_id = f"Google|{random.randint(10000000,99999999)}-{random.randint(1000,9999)}-{random.randint(1000,9999)}-{random.randint(1000,9999)}-{random.randint(100000000000,999999999999)}"
    major_login.client_ip = ""
    major_login.language = "en"
    major_login.open_id = open_id
    major_login.open_id_type = "4"
    
    # FIXED: memory_available সঠিকভাবে সেট করা
    major_login.memory_available.version = 55
    major_login.memory_available.hidden_value = 81
    
    major_login.access_token = access_token
    major_login.platform_sdk_id = 2
    major_login.network_operator_a = "Verizon"
    major_login.network_type_a = "WIFI"
    major_login.client_using_version = "7428b253defc164018c604a1ebbfebdf"
    major_login.external_storage_total = random.randint(120000, 130000)
    major_login.external_storage_available = random.randint(38000, 52000)
    major_login.internal_storage_total = random.randint(100000, 120000)
    major_login.internal_storage_available = random.randint(18000, 32000)
    major_login.game_disk_storage_available = random.randint(18000, 28080)
    major_login.external_sdcard_avail_storage = random.randint(28080, 60000)
    major_login.external_sdcard_total_storage = random.randint(110000, 130000)
    major_login.login_by = 3
    major_login.library_path = "/data/app/~~random/base.apk"
    major_login.reg_avatar = 1
    major_login.library_token = "hash|base.apk"
    major_login.channel_type = 3
    major_login.cpu_type = 2
    major_login.cpu_architecture = "64"
    major_login.login_open_id_type = 4
    major_login.loading_time = random.randint(9000, 18000)
    major_login.release_channel = "android"
    major_login.extra_info = "KqsHTy3KUhvha/qugOBot9Bf7gcwqrf2btWC5rnrKZxrHIxEFfgxmPVkTxN+2dHiSprlxvm2Kl6o8EEgBJy7FzLLpbARlcqc2f/GQz+6UsLSMGXd"
    major_login.android_engine_init_flag = 110009
    major_login.if_push = 1
    major_login.is_vpn = 0
    major_login.origin_platform_type = "4"
    major_login.primary_platform_type = "4"
    major_login.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
    
    string = major_login.SerializeToString()
    key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(string, AES.block_size)
    encrypted_payload = cipher.encrypt(padded_message)
    return encrypted_payload

async def MajorLogin(payload):
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
            async with session.post(login_url+"MajorLogin", data=payload, headers=Hr, ssl=ssl_ctx) as resp:
                return await resp.read() if resp.status==200 else None
    except Exception as e:
        print(f"⚠️ MajorLogin error: {e}")
        return None

async def GetLoginData(base_url, payload, token):
    headers = Hr.copy()
    headers['Authorization'] = f"Bearer {token}"
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
            async with session.post(f"{base_url}/GetLoginData", data=payload, headers=headers, ssl=ssl_ctx) as resp:
                return await resp.read() if resp.status==200 else None
    except Exception as e:
        print(f"⚠️ GetLoginData error: {e}")
        return None

async def xAuThSTarTuP(TarGeT, token, timestamp, key, iv):
    uid_hex = hex(TarGeT)[2:]
    uid_length = len(uid_hex)
    encrypted_timestamp = await DecodE_HeX(timestamp)
    encrypted_packet = await EnC_PacKeT(token.encode().hex(), key, iv)
    encrypted_packet_length = hex(len(encrypted_packet)//2)[2:]
    headers = '0000000'
    if uid_length==8: headers = '00000000'
    elif uid_length==10: headers = '000000'
    elif uid_length==7: headers = '000000000'
    return f"0115{headers}{uid_hex}{encrypted_timestamp}00000{encrypted_packet_length}{encrypted_packet}"

# ========== BOT CLIENT - ONLY ONLINE ==========
class FreeFireBot:
    def __init__(self, uid, password, server='bd'):
        self.uid = uid
        self.password = password
        self.server = server
        self.is_running = True
        self.online_writer = None
        self.reader = None
        self.key = None
        self.iv = None
        self.region = None
        self.tasks = []
        self.is_online = False
        
        # সেশন ভেরিয়েবলসমূহ
        self.online_ip = None
        self.online_port = None
        self.auth_token = None
        
        # Multiplexing এর জন্য ফিউচার এবং লক ভেরিয়েবল
        self.query_future = None
        self.query_lock = asyncio.Lock()

    async def tcp_online(self, ip, port, auth_token):
        while self.is_running:
            try:
                reader, writer = await asyncio.open_connection(ip, int(port))
                writer.write(bytes.fromhex(auth_token))
                await writer.drain()
                self.reader = reader
                self.online_writer = writer
                self.is_online = True
                print(f"✅ Bot {self.uid} Online ({self.server.upper()})")
                
                while self.is_running and self.is_online:
                    try:
                        data = await asyncio.wait_for(self.reader.read(65536), timeout=1.0)
                        if not data:
                            break
                        
                        # ফিউচারে রেসপন্স প্রেরণ
                        if self.query_future and not self.query_future.done():
                            pt, pl = await _scan(data, self.key, self.iv)
                            if pt in ('0f', '0e'):
                                self.query_future.set_result(data)
                                
                    except asyncio.TimeoutError:
                        continue
                    except Exception:
                        break
                        
            except Exception as e:
                print(f"⚠️ Bot {self.uid} connection error: {e}")
            
            if self.query_future and not self.query_future.done():
                self.query_future.set_exception(Exception("Connection closed"))
                
            self.online_writer = None
            self.reader = None
            self.is_online = False
            print(f"⚠️ Bot {self.uid} disconnected, reconnecting...")
            await asyncio.sleep(3)

    async def tcp_chat(self, ip, port, auth_token, key, iv, ready_event):
        while self.is_running:
            try:
                reader, writer = await asyncio.open_connection(ip, int(port))
                writer.write(bytes.fromhex(auth_token))
                await writer.drain()
                ready_event.set()
                
                while self.is_running:
                    try:
                        data = await asyncio.wait_for(reader.read(4096), timeout=1.0)
                        if not data:
                            break
                    except asyncio.TimeoutError:
                        continue
                    except Exception:
                        break
                        
            except Exception:
                pass
            await asyncio.sleep(2)

    async def keep_online_forever(self):
        print(f"🔄 Bot {self.uid} ({self.server.upper()}) attempting login...")
        
        while self.is_running:
            try:
                open_id, access_token = await GeNeRaTeAccAccess(self.uid, self.password)
                if not open_id:
                    print(f"❌ Bot {self.uid} Auth Failed!")
                    await asyncio.sleep(5)
                    continue
                    
                payload = await EncRypTMajoRLoGin(open_id, access_token)
                response = await MajorLogin(payload)
                if not response:
                    print(f"❌ Bot {self.uid} Major Login Failed!")
                    await asyncio.sleep(5)
                    continue
                    
                auth_data = MajoRLoGinrEs_pb2.MajorLoginRes()
                auth_data.ParseFromString(response)
                
                login_data = await GetLoginData(auth_data.url, payload, auth_data.token)
                if not login_data:
                    print(f"❌ Bot {self.uid} GetLoginData Failed!")
                    await asyncio.sleep(5)
                    continue
                    
                port_data = PorTs_pb2.GetLoginData()
                port_data.ParseFromString(login_data)
                
                self.key = auth_data.key
                self.iv = auth_data.iv
                self.region = auth_data.region
                
                online_ip, online_port = port_data.Online_IP_Port.split(":")
                chat_ip, chat_port = port_data.AccountIP_Port.split(":")
                
                auth_token = await xAuThSTarTuP(
                    auth_data.account_uid, 
                    auth_data.token, 
                    auth_data.timestamp, 
                    auth_data.key, 
                    auth_data.iv
                )
                
                self.online_ip = online_ip
                self.online_port = int(online_port)
                self.auth_token = auth_token
                
                ready = asyncio.Event()
                t1 = asyncio.create_task(
                    self.tcp_chat(chat_ip, chat_port, auth_token, auth_data.key, auth_data.iv, ready)
                )
                self.tasks.append(t1)
                await ready.wait()
                
                t2 = asyncio.create_task(
                    self.tcp_online(online_ip, online_port, auth_token)
                )
                self.tasks.append(t2)
                
                # সচল ডিকশনারিতে যুক্ত করা
                if self.server == 'bd':
                    connected_clients_bd[str(self.uid)] = self
                else:
                    connected_clients_ind[str(self.uid)] = self
                
                await asyncio.gather(t1, t2, return_exceptions=True)
                
            except Exception as e:
                print(f"❌ Bot {self.uid} Error: {e}")
            await asyncio.sleep(3)

    async def disconnect(self):
        self.is_running = False
        self.online_writer = None
        self.reader = None
        self.is_online = False
        if self.server == 'bd':
            connected_clients_bd.pop(str(self.uid), None)
        else:
            connected_clients_ind.pop(str(self.uid), None)
        for task in self.tasks:
            if not task.done():
                task.cancel()
        self.tasks.clear()


# ========== ACTIVE SESSION SELECTOR ==========
def get_online_bot(server=None):
    """সচল ও অনলাইন থাকা যেকোনো একটি বট রিটার্ন করে"""
    if server == "bd":
        for bot in connected_clients_bd.values():
            if bot.is_online and bot.online_ip and bot.online_port and bot.auth_token:
                return bot
    elif server == "ind":
        for bot in connected_clients_ind.values():
            if bot.is_online and bot.online_ip and bot.online_port and bot.auth_token:
                return bot
    else:
        # Default selector across any server
        for bot in list(connected_clients_bd.values()) + list(connected_clients_ind.values()):
            if bot.is_online and bot.online_ip and bot.online_port and bot.auth_token:
                return bot
    return None


# ========== DUAL SERVER STATUS CHECKING ==========
async def find_player_and_server(uid):
    """বাংলাদেশ এবং ইন্ডিয়া উভয় সার্ভারে একযোগে কুয়েরি করে প্লেয়ারের সচল সার্ভার ডিটেক্ট করা"""
    bd_bot = get_online_bot("bd")
    ind_bot = get_online_bot("ind")
    
    tasks = []
    servers = []
    bots = []
    
    if bd_bot:
        tasks.append(_query(uid, bd_bot))
        servers.append("bd")
        bots.append(bd_bot)
    if ind_bot:
        tasks.append(_query(uid, ind_bot))
        servers.append("ind")
        bots.append(ind_bot)
        
    if not tasks:
        return None, None, None
        
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # প্রথমে এমন রেসপন্স খুঁজব যা অফলাইন বা এরর নয়
    best_idx = -1
    for idx, res in enumerate(results):
        if isinstance(res, Exception):
            continue
        status = res.get('status')
        if status not in ('OFFLINE', 'PARSE_ERROR', 'UNKNOWN', 'NO_RESPONSE', None):
            best_idx = idx
            break
            
    # যদি কোনোটিই অনলাইন না পাওয়া যায়, তবে যেকোনো সাকসেস কুয়েরি রিটার্ন করবে
    if best_idx == -1:
        for idx, res in enumerate(results):
            if not isinstance(res, Exception) and res.get('status') != 'NO_RESPONSE':
                best_idx = idx
                break
                
    if best_idx != -1:
        return servers[best_idx], bots[best_idx], results[best_idx]
    return None, None, None


# ========== PARALLEL SPAM WORKER FOR TELEGRAM ==========
async def run_room_spam_loop(uid, server, bot, status_result, duration_minutes, update: Update, sent_msg):
    """সমান্তরাল স্প্যামিং এক্সিকিউটর - প্রতিটি টার্গেট আলাদা থ্রেডে সমান্তরালভাবে সচল থাকবে"""
    start_time = time.time()
    duration_seconds = duration_minutes * 60
    
    room_id = status_result['details']['room_id']
    
    await sent_msg.edit_text(
        f"🎯 কাস্টম রুম পাওয়া গেছে ({server.upper()})!\n"
        f"🏠 রুম আইডি: `{room_id}`\n"
        f"🔥 স্প্যাম চালু হচ্ছে ( can-spam 1 bot )...\n"
        f"⚡ স্পিড: প্রতি সেকেন্ডে ১০টি রিকোয়েস্ট (আলাদা আলাদা ব্যাচ ও ব্যানার)\n"
        f"⏱️ সময়কাল: `{duration_minutes}` মিনিট\n"
        f"🛑 স্প্যাম থামাতে লিখুন: `/stop {uid}`"
    )
    
    # স্প্যামিং করার জন্য একটি নির্দিষ্ট সিঙ্গেল বট বরাদ্দ রাখা হলো
    active_bot = bot
    
    try:
        while time.time() - start_time < duration_seconds:
            # যদি বরাদ্দকৃত বটটি অফলাইন হয়ে যায়, তবে সার্ভার অনুযায়ী নতুন আরেকটি সক্রিয় বট নেওয়া হবে
            if not active_bot.is_online or not active_bot.online_writer:
                fallback_bot = get_online_bot(server)
                if not fallback_bot:
                    await asyncio.sleep(1.0)
                    continue
                active_bot = fallback_bot
                
            # প্রতি সেকেন্ডে ১০টি করে রিকোয়েস্ট পাঠানোর মাইক্রো-লুপ (১০ * ০.১ সেকেন্ড = ১ সেকেন্ড)
            for _ in range(10):
                if time.time() - start_time >= duration_seconds:
                    break
                
                # প্রতিবার সম্পূর্ণ র্যান্ডম ব্যাচ কোড
                same_value = random.choice([32768])
                # প্রতিবার সম্পূর্ণ র্যান্ডম অবতার/ব্যানার
                avatar = random.choice([902053010, 902043024, 902042011, 902043018, 902027027, 902043017])
                # প্রতিবার র্যান্ডম কালার কোড
                color = get_random_color()
                
                fields = {
                    1: 78,
                    2: {
                        1: int(room_id),  
                        2: f"[C][B]{color} ARIYAN",  
                        3: {
                            2: 1,
                            3: 1
                        },
                        4: 330,      
                        5: 6000,     
                        6: 201,      
                        10: int(avatar),  
                        11: int(uid), # Target UID
                        12: 1,       
                        15: {
                            1: 1,
                            2: same_value  
                        },
                        16: same_value,    
                        18: {
                            1: 11481904755,  
                            2: 8,
                            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
                        },
                        31: {
                            1: 1,
                            2: same_value  
                        },
                        32: same_value,    
                        34: {
                            1: int(uid),   
                            2: 8,
                            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
                        }
                    }
                }
                
                # প্যাকেট জেনারেশন ও সাইলেন্ট ড্রেইন
                try:
                    packet = await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0e15', active_bot.key, active_bot.iv)
                    active_bot.online_writer.write(packet)
                    await active_bot.online_writer.drain()
                except:
                    pass
                
                await asyncio.sleep(0.3) # ০.১ সেকেন্ড ডিলি = প্রতি সেকেন্ডে ১০টি প্যাকেট
                
        await update.message.reply_text(f"✅ টার্গেট `{uid}` এর ওপর নির্ধারিত `{duration_minutes}` মিনিটের স্প্যামিং সম্পন্ন হয়েছে!")
    except asyncio.CancelledError:
        await update.message.reply_text(f"🛑 টার্গেট `{uid}` এর ওপর চলমান স্প্যামিং সফলভাবে বন্ধ করা হয়েছে!")
    except Exception as e:
        await update.message.reply_text(f"❌ স্প্যামিংয়ের সময় একটি ত্রুটি ঘটেছে: `{e}`")
    finally:
        active_spam_tasks.pop(str(uid), None)


# ========== TELEGRAM HANDLERS ==========
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🔥 WELCOME TO ARIYAN BOT 🔥\n\n"
        f"📌 Version: {ob} - {version}\n"
        "BD & IND Dual Server Keep-Alive Active.\n\n"
        "👉 `/status` – চেক অনলাইন বটসমূহ\n"
        "👉 `/status <UID>` – প্লেয়ার স্ট্যাটাস কুয়েরি করুন\n"
        "👉 `/room <UID> [Minutes]` – স্বয়ংক্রিয় দ্বৈত কুয়েরি + কাস্টম অটো স্প্যাম\n"
        "👉 `/stop <UID>` – নির্দিষ্ট ইউজারের স্প্যাম বন্ধ করুন\n"
        "অথবা সরাসরি যেকোনো UID টেক্সট হিসেবে পাঠান।"
    )
    await update.message.reply_text(boxed(text, " ARIYAN BOT "), parse_mode='Markdown')

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        uid = context.args[0].strip()
        if uid.isdigit():
            # স্বয়ংক্রিয় দ্বৈত সার্ভার কুয়েরি
            sent_msg = await update.message.reply_text("🔍 বাংলাদেশ ও ইন্ডিয়া উভয় সার্ভারে চেক করা হচ্ছে...")
            server, bot, result = await find_player_and_server(uid)
            if server and result:
                box_text = generate_styled_box(uid, result)
                await sent_msg.edit_text(f"🟢 Server: `{server.upper()}`\n\n```\n{box_text}\n```", parse_mode="Markdown")
            else:
                await sent_msg.edit_text("❌ কোনো সার্ভার থেকেই প্লেয়ারের তথ্য পাওয়া যায়নি!")
            return
            
    # আর্গুমেন্ট না থাকলে কিপ-অ্যালাইভ বটের নিজস্ব স্ট্যাটাস দেখাবে
    total_bd = len(connected_clients_bd)
    total_ind = len(connected_clients_ind)
    
    bd_online_list = [uid for uid, b in connected_clients_bd.items() if b.is_online]
    ind_online_list = [uid for uid, b in connected_clients_ind.items() if b.is_online]
    
    status_text = (
        f"🇧🇩 BD Online Bots: {len(bd_online_list)}/{total_bd}\n"
        f"📌 Active BD: " + (", ".join(bd_online_list[:5]) if bd_online_list else "None") + "\n\n"
        f"🇮🇳 IND Online Bots: {len(ind_online_list)}/{total_ind}\n"
        f"📌 Active IND: " + (", ".join(ind_online_list[:5]) if ind_online_list else "None")
    )
    await update.message.reply_text(boxed(status_text, " STATUS "), parse_mode='Markdown')

async def room_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # /room <UID> [Minutes]
    if not context.args:
        await update.message.reply_text("❌ ব্যবহার বিধি: `/room <UID> [Minutes]`\nউদাহরণ: `/room 5411923563 10`")
        return
        
    uid = context.args[0].strip()
    if not uid.isdigit():
        await update.message.reply_text("❌ অনুগ্রহ করে সঠিক সংখ্যামূলক UID প্রদান করুন।")
        return
        
    # সময় না দিলে ডিফোল্ট ৫ মিনিট চলবে
    duration = 5
    if len(context.args) > 1 and context.args[1].isdigit():
        duration = int(context.args[1])
        
    if str(uid) in active_spam_tasks:
        await update.message.reply_text(f"⚠️ টার্গেট `{uid}` এর ওপর অলরেডি একটি স্প্যাম রানিং আছে!")
        return
        
    sent_msg = await update.message.reply_text("🔍 দ্বৈত সার্ভার থেকে টার্গেটের লাইভ সেশন এবং রুম চেক করা হচ্ছে...")
    server, bot, result = await find_player_and_server(uid)
    
    if server and result:
        status = result.get('status')
        status_desc = result.get('description', 'অফলাইন/লবিতে আছে')
        
        # রুম আইডি কুয়েরি
        room_id = None
        if status == 'IN_ROOM' and result.get('details', {}).get('room_id'):
            room_id = result['details']['room_id']
            
        # রুম কোড না পেলে স্প্যাম হবে না, বন্ধ থাকবে এবং প্লেয়ার কোথায় আছে তাই বলবে
        if not room_id:
            await sent_msg.edit_text(
                f"❌ প্লেয়ার বর্তমানে কোনো কাস্টম রুমে নেই!\n"
                f"📍 অবস্থান: `{status}` ({status_desc})\n"
                f"📌 স্প্যামিং প্রক্রিয়া শুরু করা হয়নি (বন্ধ আছে)।"
            )
            return
            
        # কাস্টম রুম পাওয়া গেছে, স্প্যামার টাস্ক সমান্তরালভাবে ব্যাকগ্রাউন্ডে চালু করা হলো
        task = asyncio.create_task(run_room_spam_loop(uid, server, bot, result, duration, update, sent_msg))
        active_spam_tasks[str(uid)] = task
    else:
        await sent_msg.edit_text("❌ কোনো সার্ভারেই প্লেয়ারকে সচল পাওয়া যায়নি বা বট অফলাইন রয়েছে!")

async def stop_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # /stop <UID>
    if not context.args:
        await update.message.reply_text("❌ ব্যবহার বিধি: `/stop <UID>`")
        return
        
    uid = context.args[0].strip()
    if str(uid) in active_spam_tasks:
        task = active_spam_tasks[str(uid)]
        task.cancel() # ব্যাকগ্রাউন্ড সমান্তরাল টাস্কটি ক্যানসেল করবে
        await update.message.reply_text(f"🛑 টার্গেট `{uid}` এর ফ্লাড বন্ধের রিকোয়েস্ট পাঠানো হয়েছে।")
    else:
        await update.message.reply_text(f"❌ টার্গেট `{uid}` এর ওপর কোনো স্প্যামিং সচল নেই!")

async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """সরাসরি সংখ্যামূলক UID টেক্সট আকারে পাঠালে স্ট্যাটাস কুয়েরি করার হ্যান্ডলার"""
    text = update.message.text.strip()
    if text.isdigit():
        sent_msg = await update.message.reply_text("🔍 বাংলাদেশ ও ইন্ডিয়া উভয় সার্ভারে চেক করা হচ্ছে...")
        server, bot, result = await find_player_and_server(text)
        if server and result:
            box_text = generate_styled_box(text, result)
            await sent_msg.edit_text(f"🟢 Server: `{server.upper()}`\n\n```\n{box_text}\n```", parse_mode="Markdown")
        else:
            await sent_msg.edit_text("❌ কোনো সার্ভার থেকেই প্লেয়ারের তথ্য পাওয়া যায়নি!")
    else:
        await update.message.reply_text("❌ অনুগ্রহ করে শুধুমাত্র সঠিক সংখ্যামূলক UID পাঠান বা কমান্ড ব্যবহার করুন।")


# ========== LOAD BOTS ==========
async def load_and_start():
    # BD বট লোডার (bd.txt থেকে)
    try:
        with open("bd.txt", "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and ":" in line:
                    uid, pwd = line.split(":")[:2]
                    bot = FreeFireBot(uid=int(uid), password=pwd, server="bd")
                    asyncio.create_task(bot.keep_online_forever())
                    await asyncio.sleep(0.5)
        print("✅ BD accounts loaded.")
    except Exception as e:
        print(f"⚠️ bd.txt load error: {e}")

    # IND বট লোডার (ind.txt থেকে)
    try:
        with open("ind.txt", "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and ":" in line:
                    uid, pwd = line.split(":")[:2]
                    bot = FreeFireBot(uid=int(uid), password=pwd, server="ind")
                    asyncio.create_task(bot.keep_online_forever())
                    await asyncio.sleep(0.5)
        print("✅ IND accounts loaded.")
    except Exception as e:
        print(f"⚠️ ind.txt load error: {e}")


# ========== AUTO RESTART EVERY 1 HOUR ==========
async def auto_restart_loop():
    """প্রতি ১ ঘণ্টা পর সম্পূর্ণ প্রোগ্রাম রিস্টার্ট করে"""
    while True:
        await asyncio.sleep(3600)  # ১ ঘণ্টা = 3600 সেকেন্ড
        print("🔄 ১ ঘণ্টা পার হয়েছে, প্রোগ্রাম রিস্টার্ট হচ্ছে...")
        
        # সব বট ডিসকানেক্ট করি
        for bot in list(connected_clients_bd.values()) + list(connected_clients_ind.values()):
            await bot.disconnect()
        
        # গ্লোবাল ডিকশনারি ক্লিয়ার করি
        connected_clients_bd.clear()
        connected_clients_ind.clear()
        
        # নতুন করে বট লোড করি
        await load_and_start()
        print("✅ প্রোগ্রাম রিস্টার্ট সম্পন্ন হয়েছে!")


# ========== MAIN ==========
def main():
    try:
        import requests
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/getUpdates"
        requests.get(url, params={"offset": -1, "limit": 1})
        print("✅ Cleared previous bot updates")
    except:
        pass
    
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # লোড এবং অটো রিস্টার্ট লুপ একসাথে চালু করি
    async def main_async():
        await load_and_start()
        # অটো রিস্টার্ট টাস্ক ব্যাকগ্রাউন্ডে চালু করি
        asyncio.create_task(auto_restart_loop())
    
    loop.run_until_complete(main_async())
    
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # হ্যান্ডলারসমূহ
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("room", room_cmd))
    app.add_handler(CommandHandler("stop", stop_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))
    
    print(f"🤖 Bot running. Send /start to begin.")
    print(f"📌 Version: {ob} - {version}")
    print("⏰ প্রতি ১ ঘণ্টা পর সম্পূর্ণ প্রোগ্রাম রিস্টার্ট হবে!")
    app.run_polling(drop_pending_updates=True)

if __name__ == '__main__':
    main()